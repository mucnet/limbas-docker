<?php

/*
	file: inline_function.php

	This file defines a function which hacks two strings so they can be
	used by the Text_Diff parser, then recomposes a single string out of
	the two original ones, with inline diffs applied.

	The inline_diff code was written by Ciprian Popovici in 2004,
	as a hack building upon the Text_Diff PEAR package.
	It is released under the GPL.

	There are 3 files in this package: inline_example.php, inline_function.php, inline_renderer.php
*/

// for the following two you need Text_Diff from PEAR installed
include_once 'extern/pear/Text/Diff.php';
include_once 'extern/pear/Text/Diff/Renderer.php';
include_once 'extern/pear/Text/Diff/Renderer/unified.php';
include_once 'extern/pear/Text/Diff/Renderer/context.php';
include_once 'extern/pear/Text/Diff/Renderer/inline.php';

// this is my own renderer
#include_once 'extern/pear/inline-diff/inline_renderer.php';

function inline_diff($text1, $text2, $nl) {

	$hlines1 = explode(" ", str_replace("\n"," ".$nl,$text1));
	$hlines2 = explode(" ", str_replace("\n"," ".$nl,$text2));
	

	// create the diff object
	#$diff = new Text_Diff($hlines1, $hlines2);
	$diff = new Text_Diff('shell', array($hlines1, $hlines2));

	// get the diff in unified format
	// you can add 4 other parameters, which will be the ins/del prefix/suffix tags
	#$renderer = new Text_Diff_Renderer_inline(50000);
	$renderer = new Text_Diff_Renderer_inline();
	echo $renderer->render($diff);

}

?>