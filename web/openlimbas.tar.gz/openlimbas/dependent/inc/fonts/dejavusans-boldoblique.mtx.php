<?php
$name='DejaVuSans-BoldOblique';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 262212,
  'FontBBox' => '[-1067 -388 2005 1121]',
  'ItalicAngle' => -11.0,
  'StemV' => 165.0,
  'MissingWidth' => 600.0,
);
$up=-63;
$ut=44;
$ttffile='inc/fonts/DejaVuSans-BoldOblique.ttf';
$originalsize=511900;
$fontkey='dejavu sansBI';
?>