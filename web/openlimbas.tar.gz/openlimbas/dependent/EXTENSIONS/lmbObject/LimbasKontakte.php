<?php
class LimbasKontakte extends LimbasRecord
{
	public function __construct($attributes=null)
	{
		parent::__construct('Kontakte', $attributes);
	}
	
	public static function createModel($attributes=null)
	{
		return parent::model('Kontakte', $attributes);
	}
}